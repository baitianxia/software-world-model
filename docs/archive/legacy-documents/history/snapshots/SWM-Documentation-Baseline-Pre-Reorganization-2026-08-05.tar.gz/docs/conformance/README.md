# Contract Conformance 索引

> Conformance Fixture 定义机械验证方法；Fixture 文档、真实运行结果和 Capability Evaluation 是不同产物。

| Fixture | 状态 | 验证对象 |
|---|---|---|
| [CC-MODEL-NO-TOOLS-001](CC-MODEL-NO-TOOLS-001.md) | Defined — Not Executed | OpenAI Responses no-tools Adapter 的输入闭包、无外部访问、模型身份和生产 Sink 拒绝 |

当前 Fixture 尚无 Adapter 实现 Commit、Provider Configuration Revision、exact Model Reference 或真实 Run，因此不能标记为 Passed，也不能为模型 Strategy 签发生产资格。

未来真实执行结果应作为独立不可变 Result 保存，并固定：Fixture Revision、实现 Commit、Adapter Profile、Provider 配置、Model Reference、原始 Capture / Log Reference 和 Result Digest。Fixture 本身不因某次 Run 结果而改写。
