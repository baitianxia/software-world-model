# Software World Model 文档导航

> 本文件是非规范性导航入口，不定义架构或实施契约，也不参与已冻结的 Design / Implementation Baseline。文档树已整体迁移到 `docs/`，内部相对层级保持不变，以维持文档链接和 SHA-256 完整性。

## 1. 当前状态

- 概要架构：`SWM-ARCH@1.2`，当前基线。
- 详细设计：22 个主题 `Accepted`，2 个条件主题 `In Review`。
- 实施准备：`WP-0 Complete / WP-1 Ready`。
- 编码状态：尚未进入 WP-1，本工作区中的 `demo/` 仅为历史设计验证实现，不是生产代码基线。
- Provider 状态：no-tools Adapter 已选定；Conformance Fixture 已定义但尚未执行。

## 2. 推荐阅读顺序

```mermaid
flowchart TD
    A["概要架构基线<br/>系统定位、原则与模块边界"]
    B["详细设计总纲<br/>主题、依赖与治理规则"]
    C["设计基线 Manifest<br/>固定可采用的 Accepted 设计"]
    D["Iteration 001 实施计划<br/>选择首个纵向切片"]
    E["实施基线 Manifest<br/>固定编码前实施契约"]

    A --> B --> C --> D --> E
```

1. [概要架构基线](Software_World_Model_Architecture_Baseline.md)
2. [详细设计总纲](Software_World_Model_Detailed_Design.md)
3. [Design Baseline Manifest — Iteration 001](Design_Baseline_Manifest_Iteration_001.md)
4. [Iteration 001 实施计划](Implementation_Plan_Iteration_001.md)
5. [Implementation Baseline Manifest — Iteration 001](Implementation_Baseline_Manifest_Iteration_001.md)

如果只需要判断“当前什么设计有效、下一步能做什么”，按上述五份文档阅读即可。

## 3. 目录结构

```text
software-world-model/
├── README.md                                      # 仓库入口
├── docs/
│   ├── README.md                                  # 完整文档导航
│   ├── Software_World_Model_Architecture_Baseline.md
│   ├── Software_World_Model_Detailed_Design.md
│   ├── Design_Baseline_Manifest_Iteration_001.md
│   ├── Implementation_Plan_Iteration_001.md
│   ├── Implementation_Baseline_Manifest_Iteration_001.md
│   ├── *_Record / *_Validation / *_Log            # 治理与历史记录
│   ├── detailed-design/                            # 主题详细设计及索引
│   ├── implementation-baseline/                    # Iteration 001 实施契约及索引
│   └── conformance/                                # Contract Conformance Fixture
├── demo/                                          # 历史设计验证 Demo，非生产实现
└── validation-projects/                           # 外部验证输入，不属于平台设计
```

| 目录 | 内容 | 权威边界 |
|---|---|---|
| [detailed-design/](detailed-design/README.md) | 24 个主题详细设计 | 22 个 Accepted 主题由 Design Baseline 固定；2 个仍为 In Review |
| [implementation-baseline/](implementation-baseline/README.md) | Schema、Local Git、错误分类与模型 Adapter Profile | 由 Implementation Baseline 固定；文档冻结不表示实现测试通过 |
| [conformance/](conformance/README.md) | 可执行的一致性测试规约 | Fixture 与真实 Result 分离；当前 no-tools Fixture 未执行 |
| [demo/](../demo/README.md) | 用于证伪和验证架构的 Python / SQLite 纵向切片 | 不是生产实现、当前实施基线或技术栈决定 |
| [validation-projects/](../validation-projects/README.md) | `mall` 等外部项目快照 | 只作为验证输入，不纳入平台文档治理 |

## 4. 当前权威文档

| 层级 | 文档 | 当前状态 | 作用 |
|---|---|---|---|
| 概要架构 | [Software_World_Model_Architecture_Baseline.md](Software_World_Model_Architecture_Baseline.md) | SWM-ARCH@1.2 / Baseline | 定义系统级稳定职责、边界和原则 |
| 详细设计治理 | [Software_World_Model_Detailed_Design.md](Software_World_Model_Detailed_Design.md) | Accepted | 定义主题划分、依赖、状态和变更规则 |
| 设计版本闭包 | [Design_Baseline_Manifest_Iteration_001.md](Design_Baseline_Manifest_Iteration_001.md) | Frozen | 固定架构、总纲及 22 个 Accepted 主题摘要 |
| 迭代选择 | [Implementation_Plan_Iteration_001.md](Implementation_Plan_Iteration_001.md) | WP-0 Complete / WP-1 Ready | 选择首个纵向实现切片和工作包顺序 |
| 实施契约闭包 | [Implementation_Baseline_Manifest_Iteration_001.md](Implementation_Baseline_Manifest_Iteration_001.md) | Frozen | 固定编码前 Schema、Provider、Adapter、错误和 Fixture 契约 |

权威顺序是“上游一般约束优先于下游实施选择”。Demo、验证记录和历史稿都不能覆盖上述基线。

## 5. 决策、评审与接受记录

| 文档 | 类型 | 使用方式 |
|---|---|---|
| [Architecture_Decision_Log.md](Architecture_Decision_Log.md) | 架构决策日志 | 解释重要选择及其演进；不是替代当前架构正文的第二份规范 |
| [Detailed_Design_Review_Record_001.md](Detailed_Design_Review_Record_001.md) | 静态评审记录 | 保存评审发现及当时结果 |
| [Detailed_Design_Acceptance_Record_001.md](Detailed_Design_Acceptance_Record_001.md) | 接受决定 | 批准总纲与 22 个主题进入 Accepted |

## 6. 验证与产品价值证据

这些文档记录实验条件、失败和结论，不是当前生产实现规范：

| 文档组 | 文档 |
|---|---|
| 架构验证 | [验证基线](Architecture_Validation_Baseline.md)、[验证记录](Architecture_Validation_Log.md) |
| 产品价值探索 | [验证记录](Product_Value_Validation_Log.md) |
| 冻结 Holdout | [基线](Product_Value_Holdout_Baseline.md)、[勘误](Product_Value_Holdout_Baseline_Errata.md)、[Run 001](Product_Value_Holdout_Run_001.md) |

冻结实验输入保留其冻结时状态；后续结果记录在独立 Run / Log 中，不回写历史基线。

## 7. 历史入口

| 文档 | 状态 | 当前替代文档 |
|---|---|---|
| [Software_World_Model_Architecture_Design.md](Software_World_Model_Architecture_Design.md) | 历史输入稿 V1.0 | [概要架构基线 V1.2](Software_World_Model_Architecture_Baseline.md) |
| [Software_World_Model_MVP_Detailed_Design.md](Software_World_Model_MVP_Detailed_Design.md) | Superseded 兼容入口 | [详细设计总纲](Software_World_Model_Detailed_Design.md) 与 [Iteration 001 实施计划](Implementation_Plan_Iteration_001.md) |

历史入口只用于追溯旧链接，不应作为新设计或编码依据。

## 8. 文档维护规则

1. 当前冻结文件不原地改写规范内容；规范语义变化通过新版本和新 Manifest 管理。
2. 新的一般设计进入对应 `detailed-design/` 主题，不写入实施计划或 Demo 说明。
3. 某次迭代的具体选择进入实施计划与 `implementation-baseline/`，不能反向改变 Accepted 设计。
4. Conformance Fixture 放在 `conformance/`；真实执行结果应使用独立、不可变的 Result 文档。
5. Demo 只回答已登记的设计问题，不成为生产实现或文档权威。
6. 整棵文档树迁移且文件内容、内部相对层级不变时，可以在完整重算摘要并检查链接后完成；只要文件内容或基线内相对路径发生变化，就必须在新迭代统一修改链接、重算摘要并创建新 Manifest。
