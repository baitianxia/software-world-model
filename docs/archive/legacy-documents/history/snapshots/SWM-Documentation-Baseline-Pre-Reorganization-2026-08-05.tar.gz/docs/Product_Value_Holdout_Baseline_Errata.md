# PV-HOLDOUT-001 冻结基线勘误

## E-001：H-03 单品促销输出价格

- 发现时间：2026-08-02，首轮两组结果均完成且独立评分产生之后
- 原冻结文件与 SHA-256：保持不变，作为实验预注册记录
- 影响范围：H-03 `promotionType=1` 的一个黄金答案短语及据此产生的首次评分

冻结基线写成：

> 显式用 SKU 促销价覆盖输出价格

固定 Revision `0504e86b1f1b6f1b8aa6a734d37a90fb67346be7` 的源码实际为：

```java
BigDecimal originalPrice = skuStock.getPrice();
cartPromotionItem.setPrice(originalPrice);
cartPromotionItem.setReduceAmount(
    originalPrice.subtract(skuStock.getPromotionPrice())
);
```

因此正确黄金答案是：

> `promotionType=1` 显式用 SKU 原价覆盖输出价格，单件减免为 SKU 原价减 SKU 促销价。

证据位置：`mall-portal/src/main/java/com/macro/mall/portal/service/impl/OmsPromotionServiceImpl.java:48-52`。

两组答案都陈述为 SKU 原价，均不应在该项扣分。该修正不能用于改变题目、增加评分项或修改实现，只用于消除冻结黄金答案自身的事实错误。

## E-002：H-03 无优惠路径的 `realStock` 表述边界

冻结基线中的“无优惠路径只是不设置 `realStock`”只适用于 **SKU 关联缺失** 的情况，不表示无优惠路径永远不设置该字段。源码规则是：

- 找到 SKU：`realStock = stock - lockStock`；
- 找不到 SKU：继续输出该行，但不设置 `realStock`。

证据位置：同文件 `159-171`，尤其是 `165-168` 的空值判断。

因此，只陈述无优惠 helper 在正常 SKU 存在时设置 `realStock` 并不构成错误；没有说明缺 SKU 分支则属于该评分点的信息不完整。

