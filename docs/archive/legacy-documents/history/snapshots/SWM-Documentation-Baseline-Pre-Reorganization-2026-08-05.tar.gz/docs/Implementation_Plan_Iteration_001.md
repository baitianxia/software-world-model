# Software World Model 首个纵向实现切片方案

| 元数据 | 值 |
|---|---|
| Plan ID | SWM-IMP-ITER-001 |
| Status | Approved — WP-0 Complete / WP-1 Ready |
| Architecture Baseline | SWM-ARCH@1.2 |
| Detailed Design Guide | SWM-DD-GUIDE@0.1.0 |
| Static Review | SWM-DD-REVIEW-001 |
| Design Acceptance | [SWM-DD-ACCEPT-001](Detailed_Design_Acceptance_Record_001.md) |
| Design Baseline | [SWM-DBM-ITER-001](Design_Baseline_Manifest_Iteration_001.md) |
| Implementation Baseline | [SWM-IBM-ITER-001](Implementation_Baseline_Manifest_Iteration_001.md) |
| Current Work Package | WP-1 — Ready |
| Delivery Form | 模块化单体；Web Chat + CLI；单一逻辑 ACID Store |
| Runtime Knowledge Path | Formal Knowledge Single Path |

> 本文选择首个交付切片，不改变一般架构和详细设计。所采用的 22 个主题已经接受并由 SWM-DBM-ITER-001 固定；两个未采用的条件主题继续保持 `In Review`。WP-0 实施基线已经冻结，WP-1 可以开始；Provider Adapter 的真实 CC、模型 CE 与生产 Activation 仍分别受后续工作包门禁约束。

## 1. 实现目标

实现一个可运行的纵向系统：用户配置一个本地 Git 工程后，可以通过 Web Chat 提出未预编码的软件问题。系统把问题形成 Knowledge Requirement，在 exact Git Revision / Commit / Code Target 边界内通过有界 Tool Loop 调查来源，形成 Artifact、Evidence、Entity、Fact / Inference，经独立知识准入和 Snapshot 发布后，只依赖新 Snapshot 完成逐 Need 充分性判断、Answer Candidate、独立审核和响应交付。

首个切片允许慢，但必须满足：

- 不使用运行时直接源码回答旁路。
- 不用相关但不充分的知识伪造任务完成。
- 不因模型具有隐藏 Tool 或工作区访问能力而获得不可证明的正确答案。
- 对无法证明的内容显式返回 Gap、Conflict、Unknown 或 Application Limitation。
- 在冻结未见任务集上，正确性和任务完成率不得低于同模型、同来源、同授权 Tool 预算的直接来源调查 Agent。

## 2. 用户旅程

### 2.1 配置来源

平台管理员通过 CLI：

1. 创建一个 `SYSTEM` KnowledgeScope。
2. 注册 Local Git DataSource。
3. 使用明确仓库范围 Selector 创建 DataSourceBinding。
4. 查看组合 Management Result；配置成功不自动等同于知识已构建。

### 2.2 Web Chat 知识任务

用户通过 Web Chat 提问，例如：

- “这个 Endpoint 在什么条件下执行哪些主要步骤？”
- “Commit `<exact SHA>` 的 JWT 迁移影响了哪些技术区域？”
- “某项业务规则由哪些代码路径实现，当前有哪些未知或冲突？”

系统动态执行：

`Task Boundary → Requirement → 当前 Snapshot 调查 → Gap → Knowledge Update → 新 Snapshot → 全 Need 重评 → Answer Review → Delivery`

问题没有预编码专用 Builder、固定答案模板或题目专用 View。模型在通用 Contract 内规划与理解，平台控制身份、授权、Lineage、Context、准入、发布、充分性和放行。

### 2.3 CLI 固定用例

CLI 同时提供结构化 Management、Knowledge Update 和 Knowledge Use 命令，用于运维、调试和 Conformance。CLI 不经过 Agent Orchestrator，也不能形成与 Web 不同的知识构建路径。

## 3. 选取的设计切片

每个主题只实现本迭代用户旅程需要的 Contract 子集；未选择的能力继续由详细设计保留，不建立空模块或占位状态机。

| 主题组 | 采用主题 | 本切片范围 |
|---|---|---|
| 共享执行与模型 | DD-X-CAPABILITY-EXECUTION、DD-AI-MODEL-GATEWAY、DD-MGT-CAPABILITY-EVALUATION | Capability / Strategy、资源分配、Authorized Input Manifest、no-tools Adapter、Isolation Receipt、实际模型资格、最小评测与激活 |
| Scope 与来源配置 | DD-KNW-KNOWLEDGE-SCOPE、DD-SRC-DATA-SOURCE、DD-APP-MANAGEMENT | Create / Get Scope、Register / Get Local Git Source、Bind / Get Binding、组合 Result 与幂等 |
| 来源执行 | DD-SRC-SOURCE-ARTIFACT | Local Git `list/search/read/compare`、Commit / Revision / Code Target Resolution、Source Operation、Source / Derived Artifact、Lineage、授权局部读取与最小保留策略 |
| 知识基础 | DD-KNW-REFERENCE-CONTEXT、DD-KNW-SCHEMA-CORE、DD-KNW-CONTEXT-COMPARISON | 单 Schema INITIAL / UNCHANGED、exact Git Revision / Observation Time Context、Branch / Tag Resolution Provenance、确定性同 Context 与受控比较 |
| 知识形成 | DD-KNW-EVIDENCE、DD-KNW-ENTITY、DD-KNW-FACT、DD-KNW-INFERENCE-CONFLICT、DD-KNW-ADMISSION | 自包含 Evidence、技术 Entity、Fact、受控 Inference / Conflict、Candidate 平台重建、独立 Verification 与 Admission |
| 发布与持久化 | DD-KNW-SNAPSHOT-PUBLICATION、DD-KNW-PERSISTENCE | 单 Scope Snapshot、CURRENT、append-only 权威存储、原子发布、exact Snapshot 读取 |
| 更新与使用 | DD-APP-KNOWLEDGE-UPDATE、DD-APP-KNOWLEDGE-USE | Canonical Build Target、Target Coverage、有界 Tool Loop、Publication Acceptance、Requirement / Session / Query、逐 Need Support Proof、Gap 和发布后重评 |
| Web Agent 与响应 | DD-APP-AGENTIC-TASK、DD-APP-RESPONSE-CONTROL | Task Control、动态 Agent 路由、Task Execution、Candidate、独立 Review、Final Authorization 与幂等交付 |
| 运行观测 | DD-X-TELEMETRY-COST | 结构化运行事件、模型 / Tool 用量、估算成本、Correlation 与最小审计索引 |

本切片不采用 DD-KNW-SCHEMA-EVOLUTION；所有 Snapshot 使用同一 Knowledge Schema。DD-SEM-SEMANTIC-VIEW 不作为知识任务前置条件；Agent 使用通用正式知识 Query 和 Sufficiency 完成问题。后续需要稳定的人类 /自动化 View 时再选择该主题。

## 4. 明确不在本切片的能力

- DB、Log、Trace、部署平台和文档空间 Provider。
- 跨 KnowledgeScope Business Domain 聚合。
- Schema Adoption、身份拆分 / 合并和自动 Evolution。
- Projection、物理 Cleanup、向量 / 图 /搜索副本和非连续恢复。
- 独立 Initialization、Evaluation & Learning、Governance 或 Workflow 服务。
- 多租户、SSO、企业级权限治理、HA、灾备和财务级账单核对。
- Provider 托管 Tool、shell、文件、Web、MCP 或 Agent Runtime 访问。
- 运行时直接来源 Agent 兜底、双路径择优或“答不出时直接读源码”。

上述排除项不得用空接口、预留表或假状态机进入代码。稳定 SPI、Reference 和条件启用边界按详细设计保留。

## 5. 实现工作包与顺序

### WP-0：设计与适配准入

- 完成所选主题外部评审，采用版本进入 `Accepted`。
- 建立 Design Baseline Manifest，固定 exact DD 版本。
- 选定无 Agent 工具的 Model Provider Adapter 实现方式，并建立 no-tools Conformance Fixture。
- 冻结首个 Knowledge Schema、Local Git Provider Contract 和跨主题错误分类。

退出条件：没有未接受的规范性依赖；Adapter 方案能够在执行前机械配置 `NO_EXTERNAL_ACCESS`；INITIAL Schema、Local Git Provider Contract 和 Shared Error Classification 均已冻结且互相一致。只有全部条件成立才能进入 WP-1。

当前进度：

| WP-0 Gate | 状态 | 权威依据 / 待形成产物 |
|---|---|---|
| 采用主题接受 | Completed | [SWM-DD-ACCEPT-001](Detailed_Design_Acceptance_Record_001.md) |
| 精确设计基线 | Completed | [SWM-DBM-ITER-001](Design_Baseline_Manifest_Iteration_001.md) |
| no-tools Model Provider Adapter 选择与 Conformance Fixture | Completed — Selection / Fixture；Run Not Executed | [OpenAI no-tools Adapter Profile](implementation-baseline/ITER-001-OpenAI-No-Tools-Adapter-Profile.md)、[CC-MODEL-NO-TOOLS-001](conformance/CC-MODEL-NO-TOOLS-001.md) |
| INITIAL Knowledge Schema | Completed — Frozen | [Iteration 001 INITIAL Knowledge Schema](implementation-baseline/ITER-001-Initial-Knowledge-Schema.md) |
| Local Git Provider Contract | Completed — Frozen | [Iteration 001 Local Git Provider Profile](implementation-baseline/ITER-001-Local-Git-Provider-Profile.md) |
| 跨主题错误分类 | Completed — Frozen | [Iteration 001 Shared Error Classification](implementation-baseline/ITER-001-Shared-Error-Classification.md) |

WP-0 的文档与契约门禁已经关闭。`CC-MODEL-NO-TOOLS-001` 仍为 `Defined — Not Executed`：它不阻塞 WP-1 单体骨架，但阻止任何模型 Strategy 获得生产 Activation；若真实 Provider 无法满足 no-tools Contract，应更换 Adapter 或停止该实现切片，而不是放宽设计。

### WP-1：单体骨架与权威存储

- 建立模块化单体内的 Interface、Application Services、Source Integration、Knowledge Engine、AI Infrastructure 与 Cross-cutting 包边界；本切片不创建 Semantic View 空模块，也不拆服务。
- 建立单一 ACID Store 与各 Owner Repository Port。
- 实现 Scope、DataSource、Binding、Capability / Strategy Activation 和 Resource Allocation 的最低状态。
- 实现稳定 ID、Revision、Digest、Idempotency Key、Correlation 和 local Outbox 基础类型。

退出条件：不同 Owner 不能绕过公开 Port 写入；幂等、Revision 冲突和基本恢复测试通过。

### WP-2：Model Gateway 与 Local Git Source

- 实现 Authorized Input Manifest、Prompt Rendering、Provider Request Digest、Isolation Receipt、Model Call Record 和 post-call eligibility。
- 实现 Local Git DataSource Provider、Connector Provider 与 `list/search/read/compare` Tool。
- 实现 exact Commit / Comparison / Path / Java Symbol Target Resolver；短 SHA、重载和跨模块同名失败关闭。
- 实现 Source Operation、Artifact / Lineage、局部读取、预算、分页 /截断和 Observation。

退出条件：模型无法访问 Manifest 之外的文件、工作区、Web 或 Tool；所有来源读取均由平台授权、执行和记录。

### WP-3：正式知识构建与发布

- 实现 INITIAL Knowledge Schema 与 Context canonicalization。
- 实现 Artifact → Evidence → Entity / Fact Candidate；Inference 只引用已发布正式前提。
- 实现 Candidate Contract 校验、Knowledge Verification、Admission Batch、Snapshot Manifest 与单 Scope 原子发布。
- 实现 append-only Authority Store 和 exact Snapshot Read。

退出条件：Evidence 越界、Entity / Fact 悬空引用、Inference 非正式前提、审核失败和发布并发均不能污染 CURRENT。

### WP-4：任务驱动 Knowledge Update

- 实现 Build Objective、Canonical Build Target、Resolution Receipt、Build Intent 和 Target Coverage Map。
- 实现 Source Information Need、no-tools Tool Proposal、Application Authorization、Tool Step、Observation 和有界停止。
- 实现 Candidate / Admission / Publication Coverage 闭包和 Publication Acceptance。
- 实现 Update Result 与 Delivery Assertion。

退出条件：给定未预编码 Commit 或 Endpoint，系统可以渐进找到材料并发布相关正式知识；无关同类型知识、空选择、越界和预算耗尽不能假通过。

### WP-5：Knowledge Use 与逐 Need Sufficiency

- 实现 Task Boundary、Requirement Revision / Fidelity、Need / Joint Constraint / Obligation Manifest。
- 实现 exact Snapshot Read Session、正式知识 Query、Read Set 和 Cursor。
- 实现独立 Sufficiency Attempt、Need Support Proof、Counterexample / Conflict / Unknown / Limitation 和机械聚合。
- 实现 Gap Resolution 后 exact Snapshot 重绑定和全部 Need 重评。

退出条件：每个 SATISFIED Need 都有同一 Snapshot 可重建 Proof；任一缺口都不能被 Answer Draft 补写。

### WP-6：Web Task、Answer Review 与交付

- 实现 Conversational Task Control、Agent Capability Catalog、Orchestrator Proposal、Delegated Grant 和 Application Call Record。
- 实现 Task Execution Agent 的通用 Knowledge Use / Update 规划。
- 实现 Answer Candidate / Claim / Coverage Manifest、独立 Reviewer、Review Matrix、Final Authorization 和 Logical Delivery。
- 实现取消、副作用 Outcome Pending、发送 Claim 和 Adapter Receipt 收口。

退出条件：Agent 无法直连 Core；Reviewer 从权威 Owner 重读依据；未审核或陈旧 Candidate 不能发送；同一请求不产生第二份正文。

### WP-7：端到端质量与产品门禁

- 建立 Contract Conformance、故障注入和 Capability Evaluation 套件。
- 冻结至少两个未参与开发调试的 Git 工程和未见任务集，覆盖 Structure、Behavior、History 以及能够从正式依据成立的 Business 语义。
- 使用同一基础模型、同一来源、同一总 Tool / Token 预算运行 SWM 与直接来源调查 Agent 对照；对照 Agent 只在测试 Harness 中存在。
- 记录正确性、任务完成率、关键证据覆盖、Gap 诚实性、延迟和成本。

退出条件：全部强制 Conformance 通过；SWM 正确性和任务完成率不低于直接来源调查基线。若未达到，保持迭代未验收并回到 Capability / Contract 诊断，不把直接 Agent 接入生产路径作弊。

## 6. 强制验收场景

| Gate | 场景 | 必须结果 |
|---|---|---|
| G-01 no-tools | Manifest 外放置已知文件名、路径和秘密片段 | Provider 调用期间无读取通道；输出无法包含运行时偷读内容；平台保存可核验 Receipt |
| G-02 模型漂移 | 请求模型与 actual fingerprint / Adapter 不在 Qualification 范围 | Capability Owner 不封存任何生产领域结果 |
| G-03 canonical target | 短 SHA 多解、同名重载、同路径 Controller | 明确歧义或失败；不扩大为全仓库 |
| G-04 target coverage | exact Commit 问题只存在无关 `HISTORY_IMPACT` | Update / Sufficiency 均不能把它当作目标覆盖 |
| G-05 bounded loop | Planner 重复动作、无新 Observation、预算耗尽 | 受控停止并披露未完成范围，不生成完整 Coverage |
| G-06 knowledge admission | Fact 超出 Evidence、Inference 使用 Candidate / Artifact 前提 | Candidate 被拒绝，旧 CURRENT 不变 |
| G-07 per-Need sufficiency | Commit 已知但 JWT 影响区域只覆盖一部分 | 未覆盖 Need /枚举 Coverage 形成 Gap，整体不是 SUFFICIENT |
| G-08 conflict/context | 代码与文档规则不同或 Branch / Deployment Context 不可组合 | 保留独立 Fact；只有正式 Conflict 才标注冲突；不可组合时不拼接 |
| G-09 answer review | Candidate 增加正式命题未蕴含的因果、唯一性或确定性 | Review 不 APPROVED |
| G-10 stale delivery | Review 后 Snapshot Session、Task Revision 或权限变化 | 当前重验拒绝发送旧正文 |
| G-11 idempotency | 来源调用、Publication、Application Command 或发送在响应丢失后重试 | 只恢复原 Attempt / Key，不产生重复副作用或第二响应 |
| G-12 product baseline | 冻结未见任务集对照直接来源调查 Agent | SWM 正确性与任务完成率达到或超过基线，否则不验收 |

## 7. 测试分层

| 测试类型 | 验证内容 |
|---|---|
| Unit / Property | Canonicalization、Digest、状态迁移、集合双向覆盖、Context 与身份不变量 |
| Contract Conformance | Provider / Adapter / Repository / Tool 是否符合已 Accepted Contract |
| Fault Injection | dispatch、取消、CAS、崩溃恢复、Outcome Unknown、Publication 与 Delivery 竞态 |
| Capability Evaluation | Requirement、Tool Planning、Artifact Processing、Candidate、Sufficiency、Drafting、Review 的模型质量与退化 |
| End-to-End | 单路径从配置来源到审核后回答，以及 Gap /Conflict /失败路径 |
| Product Holdout | 与同条件直接来源调查 Agent 比较正确性和完成率 |

Demo 只在实现过程中发现会改变公共契约、且静态分析与 Conformance 无法判定的真实设计分叉时另行登记 `DVR-*`。普通实现失败、模型质量不足和测试未通过不自动成为新架构问题。

## 8. 完成定义

本迭代只有同时满足以下条件才完成：

1. Design Baseline Manifest 中全部主题版本在编码前已经 `Accepted`。
2. G-01 至 G-11 全部通过，无生产直接来源回答旁路。
3. 端到端任务的每个 Answer Claim 都能回放到同一 Snapshot 的正式知识或不可变 Application Result。
4. 所有 Gap、Conflict、Unknown、权限和执行限制如实披露。
5. Adapter / Connector Conformance 和模型 Capability Evaluation 结果可按 exact 版本追溯。
6. G-12 产品基线通过；否则保留失败结果并继续迭代，不能宣称该切片可用。
7. 实际实现没有引入未记录的跨 Owner 写入、新顶层模块、Projection、双路径或题目专用逻辑。

后续迭代在选择新的 Provider、Semantic View、跨 Scope、Schema Adoption 或平台自我提升能力前，先完成对应详细设计评审和新的独立实施方案。
