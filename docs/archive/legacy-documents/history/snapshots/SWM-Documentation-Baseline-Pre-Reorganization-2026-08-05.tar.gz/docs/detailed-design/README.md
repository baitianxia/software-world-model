# 详细设计主题索引

> 本文件仅提供导航。主题状态、依赖和治理规则以[详细设计总纲](../Software_World_Model_Detailed_Design.md)、[接受记录](../Detailed_Design_Acceptance_Record_001.md)及[设计基线 Manifest](../Design_Baseline_Manifest_Iteration_001.md)为准。

当前共有 24 个主题：22 个 `Accepted`，2 个 `In Review`。

## 共享执行、模型与观测

| 主题 | 状态 |
|---|---|
| [DD-X-CAPABILITY-EXECUTION](DD-X-CAPABILITY-EXECUTION.md) | Accepted |
| [DD-AI-MODEL-GATEWAY](DD-AI-MODEL-GATEWAY.md) | Accepted |
| [DD-MGT-CAPABILITY-EVALUATION](DD-MGT-CAPABILITY-EVALUATION.md) | Accepted |
| [DD-X-TELEMETRY-COST](DD-X-TELEMETRY-COST.md) | Accepted |

## Scope、来源与管理

| 主题 | 状态 |
|---|---|
| [DD-KNW-KNOWLEDGE-SCOPE](DD-KNW-KNOWLEDGE-SCOPE.md) | Accepted |
| [DD-SRC-DATA-SOURCE](DD-SRC-DATA-SOURCE.md) | Accepted |
| [DD-SRC-SOURCE-ARTIFACT](DD-SRC-SOURCE-ARTIFACT.md) | Accepted |
| [DD-APP-MANAGEMENT](DD-APP-MANAGEMENT.md) | Accepted |

## Knowledge Core

| 主题 | 状态 |
|---|---|
| [DD-KNW-REFERENCE-CONTEXT](DD-KNW-REFERENCE-CONTEXT.md) | Accepted |
| [DD-KNW-SCHEMA-CORE](DD-KNW-SCHEMA-CORE.md) | Accepted |
| [DD-KNW-CONTEXT-COMPARISON](DD-KNW-CONTEXT-COMPARISON.md) | Accepted |
| [DD-KNW-EVIDENCE](DD-KNW-EVIDENCE.md) | Accepted |
| [DD-KNW-ENTITY](DD-KNW-ENTITY.md) | Accepted |
| [DD-KNW-FACT](DD-KNW-FACT.md) | Accepted |
| [DD-KNW-INFERENCE-CONFLICT](DD-KNW-INFERENCE-CONFLICT.md) | Accepted |
| [DD-KNW-ADMISSION](DD-KNW-ADMISSION.md) | Accepted |
| [DD-KNW-SNAPSHOT-PUBLICATION](DD-KNW-SNAPSHOT-PUBLICATION.md) | Accepted |
| [DD-KNW-PERSISTENCE](DD-KNW-PERSISTENCE.md) | Accepted |
| [DD-KNW-SCHEMA-EVOLUTION](DD-KNW-SCHEMA-EVOLUTION.md) | In Review；仅跨 Schema Adoption 时启用 |

## Application 与响应可信链

| 主题 | 状态 |
|---|---|
| [DD-APP-KNOWLEDGE-UPDATE](DD-APP-KNOWLEDGE-UPDATE.md) | Accepted |
| [DD-APP-KNOWLEDGE-USE](DD-APP-KNOWLEDGE-USE.md) | Accepted |
| [DD-APP-AGENTIC-TASK](DD-APP-AGENTIC-TASK.md) | Accepted |
| [DD-APP-RESPONSE-CONTROL](DD-APP-RESPONSE-CONTROL.md) | Accepted |

## 条件语义能力

| 主题 | 状态 |
|---|---|
| [DD-SEM-SEMANTIC-VIEW](DD-SEM-SEMANTIC-VIEW.md) | In Review；首个切片不依赖稳定 View |

`In Review` 主题不能被当前实现隐式使用。需要启用时，必须先完成接受决定并建立新的 Design / Implementation Baseline。
