# Iteration 001 实施契约索引

> 本目录只保存首个纵向切片在编码前选择并冻结的实施契约。一般架构与跨迭代语义仍由 Accepted 详细设计拥有。

入口：

- [Iteration 001 实施计划](../Implementation_Plan_Iteration_001.md)
- [Implementation Baseline Manifest](../Implementation_Baseline_Manifest_Iteration_001.md)
- [Design Baseline Manifest](../Design_Baseline_Manifest_Iteration_001.md)

## 契约与状态

| 产物 | 当前状态 | 作用 |
|---|---|---|
| [Local Git Provider Profile](ITER-001-Local-Git-Provider-Profile.md) | Frozen for Iteration 001 | 固定 Repository Identity、Source Context、Tool、Artifact / Payload 和解析边界 |
| [INITIAL Knowledge Schema](ITER-001-Initial-Knowledge-Schema.md) | Frozen for Iteration 001 | 固定首轮 Entity、Fact、Inference、Evidence、Admission 与 Snapshot 语义 |
| [Shared Error Classification](ITER-001-Shared-Error-Classification.md) | Frozen for Iteration 001 | 统一跨 Owner 错误投影、Outcome、Recovery 和 Exposure |
| [OpenAI no-tools Adapter Profile](ITER-001-OpenAI-No-Tools-Adapter-Profile.md) | Selected — Conformance Required | 选择无 Provider Tool、无会话、Manifest 输入闭包的 Adapter 方式 |

## 依赖关系

```mermaid
flowchart TD
    LG["Local Git Provider Profile"] --> KS["INITIAL Knowledge Schema"]
    SE["Shared Error Classification"] -. "跨主题投影" .-> LG
    SE -. "跨主题投影" .-> KS
    OA["OpenAI no-tools Adapter Profile"] --> CC["CC-MODEL-NO-TOOLS-001<br/>Defined — Not Executed"]
```

Schema 通过 exact Profile Contract Digest 单向依赖 Local Git Profile。文档中的导航反向链接不进入规范摘要，不构成契约循环。

## 状态解释

- `Frozen for Iteration 001`：本轮编码必须遵守，规范变化需要新版本和新 Manifest。
- `Selected — Conformance Required`：已选实现方式，但尚未证明真实 Adapter / Provider 合规。
- Fixture 定义、运行结果和模型 Capability Evaluation 分别管理，不能把文档冻结写成测试通过。

no-tools Fixture 位于 [conformance/](../conformance/README.md)。
